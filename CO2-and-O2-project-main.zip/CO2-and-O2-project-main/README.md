# CO2-and-O2-project

**1)Abstract of Idea: **

It is a product which works with the help of sensors and helps in detection of amount of Carbon dioxide and Oxygen and triggers the alarm when it exceeds its range.

**2)Objectives & Significance:**
 
•	The purpose of this product is to come up with new ideas and technologies that increase productivity and generate greater output with the same input. 
•	To prevent accidental deaths of infants and pets due to the increase in concentration of Carbon dioxide levels in cars. 
•	And to reduce the increase in the rate of accidents of infants due to the lighter particles of carbon dioxide and monoxide.

**3)Background of the Idea:**

•	The Background of the idea is that it is useful for the children and pets who accidentally get trapped inside the car and die due to the lack of Oxygen, or increase in the level of Carbon dioxide. 
•	And it also helps in prevention in growth of infants and pets’ suffocation due to harmful gases. 
•	When temperature rises it even detects Methane, Propane and Combustible gases…. etc and cleans the other gases as it is absorbed under low temperature.  
•	This technology is mostly useful when we go on long trips and stay for longer hours in our cars, which may lead to the increase of harmful gases in our cars, which we may breathe in. 
•	Whereas in industries it helps to detect if there is any leakage of gas, which may lead to disaster by triggering on alarm, when there is a rise in level of their harmful gases. 

**4)Proposed Solution**

•	Our technology model helps in the detection of the harmful gases around you, and gives you a signal in order to prevent further accidents. 
•	This situation is the best way you can protect your infants and pets through the respiratory problems and deaths due to these harmful gases. 
•	So, this technology enhances the productivity of cars and increase in technology basis for the safety of human beings.     
According to problem when certain type of data identified from the gas then , when data value is greater than the expected value then using the python script for Arduino, we send a single through the transmitter only 1 or 0 if 1 received by receiver then windows will open or buzzer signal will be generated.We used MQ-9 sensor.
•	MQ-9 gas sensor module has high sensitivity to Carbon Monoxide, Methane and LPG.•	MQ-9 usually applied in domestic gas leakage detector, industrial gas detector, portable gas detector, etc. 


**5)Outcomes & Scope for the future extension:**

•	Our technology model helps in the detection of the harmful gases around you, and gives you a signal in order to prevent further accidents. 
•	This situation is the best way you can protect your infants and pets through the respiratory problems and deaths due to these harmful gases. 
•	So, this technology enhances the productivity of cars and increase in technology basis for the safety of human beings.

![Screenshot (44)](https://user-images.githubusercontent.com/84395860/228846100-75b03f97-8824-4869-ae23-bcdec984284f.png)

![WhatsApp Image 2023-03-30 at 6 24 41 PM (1)](https://user-images.githubusercontent.com/84395860/228843030-ad9a27cc-11f7-4788-b23f-10c7fb8347a2.jpeg)

![WhatsApp Image 2023-03-30 at 6 24 41 PM](https://user-images.githubusercontent.com/84395860/228843038-09ed66ba-9498-492b-b97a-ed2a103fc7a7.jpeg)

![WhatsApp Image 2023-03-30 at 6 24 40 PM](https://user-images.githubusercontent.com/84395860/228843045-af3fc0d8-4451-44fd-b332-d7b64f7ade76.jpeg)

![DSC05673](https://user-images.githubusercontent.com/84395860/228843048-73f6e944-616b-4474-be50-0767a4a62501.JPG)

![DSC05577](https://user-images.githubusercontent.com/84395860/228843061-0eeb4bc4-54b1-447b-a94f-8f32783fa789.JPG)

![DSC05561](https://user-images.githubusercontent.com/84395860/228843066-ed032dce-55f8-4110-ac12-ba6ee9be62e3.JPG)

![WhatsApp Image 2023-02-10 at 8 43 38 PM](https://user-images.githubusercontent.com/84395860/228846150-fc77f138-1b2d-4765-b8ea-1aac8abe9eac.jpeg)

![WhatsApp Image 2023-02-10 at 8 43 39 PM](https://user-images.githubusercontent.com/84395860/228846163-e0da960d-ed90-4da0-8116-d436f0360d37.jpeg)
